# 💳 Moliya Bot — O'rnatish yo'riqnomasi

## 📋 Talab qilinadigan narsalar
- Telegram akkaunt
- GitHub akkaunt (bepul)
- Railway.app akkaunt (bepul)

---

## 🤖 1-QADAM: Bot tokeni olish

1. Telegramda **@BotFather** ga yozing
2. `/newbot` buyrug'ini yuboring
3. Bot nomini kiriting: `Moliya Bot`
4. Bot username kiriting: `mening_moliya_bot` (oxiri _bot bo'lishi kerak)
5. **Token** beriladi — uni saqlang!
   ```
   1234567890:ABCdefGHIjklMNOpqrSTUvwxYZ
   ```

---

## 🚀 2-QADAM: Railway.app ga joylash (BEPUL)

### GitHub orqali:
1. GitHub.com ga kiring → **New repository** → `moliya-bot`
2. Barcha fayllarni yuklang (bot.py, requirements.txt, railway.toml, Procfile)
3. **railway.app** ga kiring → **New Project** → **Deploy from GitHub repo**
4. Reponi tanlang
5. **Variables** bo'limiga kiring:
   - `BOT_TOKEN` = sizning tokeningiz
6. **Deploy** tugmasini bosing

### Yoki bevosita Railway CLI orqali:
```bash
npm install -g @railway/cli
railway login
railway init
railway up
railway variables set BOT_TOKEN=YOUR_TOKEN_HERE
```

---

## ✅ 3-QADAM: Botni tekshirish

1. Telegramda `@sizning_bot_username` ga `/start` yuboring
2. Bot javob bersa — hammasi tayyor! 🎉

---

## 💾 Ma'lumotlar haqida

- Ma'lumotlar **SQLite** da saqlanadi
- Railway.app da **doimiy disk** ishlatiladi — ma'lumot yo'qolmaydi
- Har bir foydalanuvchi alohida ma'lumotga ega

---

## 🔧 Muammolar

**Bot javob bermayapti:**
- Token to'g'ri kiritilganini tekshiring
- Railway.app da "Logs" bo'limini ko'ring

**Ma'lumot saqlanmayapti:**
- Railway.app da **Volume** qo'shing: `/app/moliya.db`

---

## 📞 Yordam

Muammo bo'lsa — Claude.ai ga murojaat qiling!
